extern void print_max();

int main()
{
    print_max();
    return 0;
}

